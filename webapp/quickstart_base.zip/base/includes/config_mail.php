
<?php
//*********************************************************************************
// Mail Configuration File
//*********************************************************************************
	$mailConfig["mail_server"] = "info@teamkits.net";
	$mailConfig["mail_mailer"] = "smtp";
	$mailConfig["mail_smtpauth"] = true;
	$mailConfig["mail_port"] = "465";
	$mailConfig["mail_username"] = "info@teamkits.net";
	$mailConfig["mail_password"] = "waltermorel";
	
	$mailConfig["mail_from"] = "info@teamkits.net";
	$mailConfig["mail_fromname"] = "info@teamkits.net";
	$mailConfig["mail_sender"] = "info@teamkits.net";
	$mailConfig["mail_admin"] = "jordan@orchardcity.ca";

?>