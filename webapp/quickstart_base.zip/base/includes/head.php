    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="icon" href="favicon.ico">
    <!-- Bootstrap core CSS -->   
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <link href="/teamkits/webapp/css/bootstrap.min.css" rel="stylesheet">
    <link href="/teamkits/webapp/css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    <link href="/teamkits/webapp/css/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css">        
    
    <link href="/teamkits/webapp/css/ui-lightness/jquery-ui-1.10.0.custom.min.css" rel="stylesheet">
    
    <link href="/teamkits/webapp/css/base-admin-3.css" rel="stylesheet">
    <link href="/teamkits/webapp/css/base-admin-3-responsive.css" rel="stylesheet">
    
    <link href="/teamkits/webapp/css/pages/dashboard.css" rel="stylesheet">   
    <link href="/teamkits/webapp/css/custom.css" rel="stylesheet">
    <link href="/teamkits/webapp/css/styles.css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<!-- it works! -->